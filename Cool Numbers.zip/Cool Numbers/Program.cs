﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cool_Numbers
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("---Cool_Numbers---");
            Console.Write("How many cool numbers do you want? ");
            {
                int iCount = int.Parse(Console.ReadLine());
                for(int i = 0; i <= iCount; i++)
                {
                    double result = Math.Pow(2, i);
                    Console.WriteLine(result);
                }
            }
            Console.ReadKey();
        }
    }
}
